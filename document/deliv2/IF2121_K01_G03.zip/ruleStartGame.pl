% startGame.
% ->menampilkan menu. Set globalvariabel dasar(level 1, time 1, day 1, dst). rule pertama yang diakses
startGame:- write('welcome to hell. collect money and pay your debt\n').